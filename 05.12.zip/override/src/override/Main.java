package override;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) throws CloneNotSupportedException {
        User user1 = new User(100, "bnj", false);


        User user2 = new User(100, "jkkll", false);

        User user3 = new User(100, "Mghsha", false);
         User user4 = (User) user1.clone();
        System.out.println(user1);
        System.out.println(user2);
        System.out.println(user4);
        System.out.println(user1.equals(user2));
        System.out.println(user4.equals(user1));
        System.out.println(user3.hashCode());
    }

}

